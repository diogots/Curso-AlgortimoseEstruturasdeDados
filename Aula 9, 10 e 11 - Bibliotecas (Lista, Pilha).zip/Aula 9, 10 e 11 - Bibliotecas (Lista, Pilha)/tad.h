#ifndef TAD_H

#define TAD_H

#include "tad.cpp"
//typedef struct node Node;
//typedef struct pilha Pilha;

#endif // TAD_H
